# IVR Log Analyzer - PowerShell HTTP server
# Designed for Windows PowerShell 5.1 and .NET HttpListener.
# Responsibilities: static files + findstr-backed streaming search.

$ErrorActionPreference = "Stop"

# Console diagnostics. Set "debug": false in config.json to reduce output.
$script:DebugEnabled = $true

function Write-Log {
    param(
        [string]$Level,
        [string]$Message
    )
    $stamp = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss.fff")
    Write-Host "[$stamp] [$Level] $Message"
}

function Write-DebugLog {
    param([string]$Message)
    if ($script:DebugEnabled) {
        Write-Log "DEBUG" $Message
    }
}

function Send-Text {
    param(
        [System.Net.HttpListenerResponse]$Response,
        [string]$Text,
        [string]$ContentType = "text/plain; charset=utf-8",
        [int]$StatusCode = 200
    )
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($Text)
    $Response.StatusCode = $StatusCode
    $Response.ContentType = $ContentType
    $Response.ContentEncoding = [System.Text.Encoding]::UTF8
    $Response.ContentLength64 = $bytes.Length
    $Response.OutputStream.Write($bytes, 0, $bytes.Length)
    $Response.Close()
}

function Send-Json {
    param(
        [System.Net.HttpListenerResponse]$Response,
        [object]$Object,
        [int]$StatusCode = 200
    )
    $json = $Object | ConvertTo-Json -Compress -Depth 6
    Send-Text -Response $Response -Text $json -ContentType "application/json; charset=utf-8" -StatusCode $StatusCode
}

function Send-NdjsonLine {
    param(
        [System.Net.HttpListenerResponse]$Response,
        [object]$Object
    )
    $json = $Object | ConvertTo-Json -Compress -Depth 8
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($json + "`r`n")
    $Response.OutputStream.Write($bytes, 0, $bytes.Length)
    $Response.OutputStream.Flush()
}

function Get-ContentType {
    param([string]$Path)
    switch ([IO.Path]::GetExtension($Path).ToLowerInvariant()) {
        ".html" { return "text/html; charset=utf-8" }
        ".js"   { return "application/javascript; charset=utf-8" }
        ".css"  { return "text/css; charset=utf-8" }
        ".json" { return "application/json; charset=utf-8" }
        ".png"  { return "image/png" }
        ".jpg"  { return "image/jpeg" }
        ".jpeg" { return "image/jpeg" }
        ".gif"  { return "image/gif" }
        ".svg"  { return "image/svg+xml" }
        ".ico"  { return "image/x-icon" }
        default { return "application/octet-stream" }
    }
}

function Resolve-ConfiguredPath {
    param([string]$Path, [string]$BaseDirectory)
    if ([IO.Path]::IsPathRooted($Path)) {
        return [IO.Path]::GetFullPath($Path)
    }
    return [IO.Path]::GetFullPath((Join-Path $BaseDirectory $Path))
}

function Get-Stats {
    param(
        [string[]]$Paths,
        [string[]]$Patterns
    )

    # Initial dashboard statistics.
    # Files are processed one line at a time; no complete log file is loaded into memory.
    $files = 0
    [Int64]$totalSize = 0
    [Int64]$totalLines = 0
    [Int64]$apiCalls = 0
    [Int64]$failures = 0
    $uniqueCalls = New-Object 'System.Collections.Generic.HashSet[string]'
    $latestFile = ""
    $latestModified = $null
    $existingLocations = 0
    $missing = @()
    $readErrors = @()
    $seenFiles = New-Object 'System.Collections.Generic.HashSet[string]'

    foreach ($dir in $Paths) {
        if (-not (Test-Path -LiteralPath $dir -PathType Container)) {
            $missing += $dir
            continue
        }

        $existingLocations++

        foreach ($pattern in $Patterns) {
            try {
                foreach ($file in [IO.Directory]::EnumerateFiles($dir, $pattern, [IO.SearchOption]::AllDirectories)) {
                    $fullFile = [IO.Path]::GetFullPath($file)
                    if (-not $seenFiles.Add($fullFile.ToLowerInvariant())) { continue }

                    try {
                        $fi = New-Object IO.FileInfo($file)
                        $files++
                        $totalSize += [Int64]$fi.Length

                        if ($null -eq $latestModified -or $fi.LastWriteTime -gt $latestModified) {
                            $latestModified = $fi.LastWriteTime
                            $latestFile = $fi.Name
                        }

                        # Stream the file line-by-line. Do not use Get-Content without
                        # a streaming loop because very large files must not be retained
                        # as an array in memory.
                        $reader = New-Object System.IO.StreamReader(
                            $file,
                            [System.Text.Encoding]::Default,
                            $true,
                            65536
                        )

                        try {
                            while (-not $reader.EndOfStream) {
                                $line = $reader.ReadLine()
                                $totalLines++

                                if ([string]::IsNullOrEmpty($line)) { continue }

                                # Call ID from SERVER-CALL-ID|...
                                $pipe = $line.IndexOf("|")
                                if ($pipe -gt 0) {
                                    $serverCall = $line.Substring(0, $pipe)
                                    $dash = $serverCall.IndexOf("-")
                                    if ($dash -gt 0 -and $dash + 1 -lt $serverCall.Length) {
                                        [void]$uniqueCalls.Add($serverCall.Substring($dash + 1))
                                    }
                                }

                                # API call count = log records containing APIClient.<method>.
                                if ($line -match 'APIClient\.[A-Za-z0-9_]+') {
                                    $apiCalls++
                                }

                                # Same failure criteria used by the browser analysis.
                                if ($line -match '(?i)failure|error|exception|statusCode\s+[45][0-9][0-9]|RESPONSE_STATUS\s+FALSE') {
                                    $failures++
                                }
                            }
                        }
                        finally {
                            $reader.Dispose()
                        }
                    }
                    catch {
                        $readErrors += "$file : $($_.Exception.Message)"
                    }
                }
            }
            catch {
                $readErrors += "$dir [$pattern] : $($_.Exception.Message)"
            }
        }
    }

    return [ordered]@{
        files = $files
        totalLines = $totalLines
        uniqueCalls = $uniqueCalls.Count
        apiCalls = $apiCalls
        failures = $failures
        totalSize = $totalSize
        latestFile = $latestFile
        latestModified = if ($latestModified) { $latestModified.ToString("yyyy-MM-dd HH:mm:ss") } else { "" }
        logPaths = @($Paths)
        existingLogPaths = $existingLocations
        missingPaths = @($missing)
        readErrors = @($readErrors)
    }
}

function Encode-Utf8Base64 {
    param([string]$Text)
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($Text)
    return [Convert]::ToBase64String($bytes)
}

function Start-FindstrSearch {
    param(
        [System.Net.HttpListenerResponse]$Response,
        [string]$Query,
        [string[]]$Paths,
        [string[]]$Patterns
    )

    $matches = 0
    $errors = 0
    $processes = 0

    Write-Log "INFO" "Search requested. Query=[$Query] Length=$($Query.Length)"
    Write-DebugLog "Configured log paths: $($Paths -join ' | ')"
    Write-DebugLog "Configured file patterns: $($Patterns -join ', ')"
    Write-DebugLog "findstr path: $env:SystemRoot\System32\findstr.exe"
    Write-DebugLog "findstr exists: $(Test-Path -LiteralPath "$env:SystemRoot\System32\findstr.exe")"

    Send-NdjsonLine $Response ([ordered]@{
        type = "search-start"
        query = $Query
    })

    foreach ($dir in $Paths) {
        Write-Log "INFO" "Checking log directory: $dir"

        if (-not (Test-Path -LiteralPath $dir -PathType Container)) {
            $errors++
            Write-Log "ERROR" "Configured log directory does not exist: $dir"
            Send-NdjsonLine $Response ([ordered]@{
                type = "search-error"
                message = "Configured log directory does not exist: $dir"
            })
            continue
        }

        try {
            $logFileCount = 0
            $counted = New-Object 'System.Collections.Generic.HashSet[string]'
            foreach ($filePattern in $Patterns) {
                foreach ($f in [IO.Directory]::EnumerateFiles($dir, $filePattern, [IO.SearchOption]::AllDirectories)) {
                    [void]$counted.Add(([IO.Path]::GetFullPath($f)).ToLowerInvariant())
                }
            }
            $logFileCount = $counted.Count
            Write-DebugLog "Directory contains approximately $logFileCount configured log files."
        } catch {
            Write-DebugLog "Could not count files in directory: $($_.Exception.Message)"
        }

        foreach ($filePattern in $Patterns) {
            $pattern = Join-Path $dir $filePattern
            $findstr = "$env:SystemRoot\System32\findstr.exe"

            # /S = recursive, /I = case-insensitive, /L = literal, /N = line number.
            # /C keeps the entire user value as one literal search string.
            $arguments = '/S /I /L /N /C:"' + $Query + '" "' + $pattern + '"'

            Write-Log "INFO" "Starting findstr for pattern [$filePattern]"
            Write-DebugLog "Pattern: [$pattern]"
            Write-DebugLog "Arguments: [$arguments]"

            $psi = New-Object System.Diagnostics.ProcessStartInfo
            $psi.FileName = $findstr
            $psi.UseShellExecute = $false
            $psi.CreateNoWindow = $true
            $psi.RedirectStandardOutput = $true
            $psi.RedirectStandardError = $true
            $psi.Arguments = $arguments

            $process = New-Object System.Diagnostics.Process
            $process.StartInfo = $psi

            $rawOutputLines = 0
            $parseFailures = 0
            $debugOutputShown = 0
            $debugMatchShown = 0
            $stderrText = ""

            try {
                if (-not (Test-Path -LiteralPath $findstr -PathType Leaf)) {
                    throw "findstr.exe was not found at $findstr"
                }

                $processes++
                $started = $process.Start()
                Write-DebugLog "Process.Start() returned [$started]. PID=$($process.Id)"

                while (-not $process.StandardOutput.EndOfStream) {
                    $outLine = $process.StandardOutput.ReadLine()
                    $rawOutputLines++

                    if ($debugOutputShown -lt 5) {
                        Write-DebugLog "findstr OUT[$rawOutputLines]: [$outLine]"
                        $debugOutputShown++
                    }

                    if ([string]::IsNullOrEmpty($outLine)) {
                        Write-DebugLog "findstr returned an empty output line."
                        continue
                    }

                    # findstr output with /N is:
                    # C:\path\file.log:123:raw log line
                    #
                    # The file path can contain a drive-letter colon, and the raw
                    # log line can contain many more colons. Use the final :digits:
                    # boundary so both normal and rotated names such as
                    # test.log.20260921 are parsed correctly.
                    $patternRegex = '^(.*):([0-9]+):(.*)$'

                    $parsed = [regex]::Match(
                        $outLine,
                        $patternRegex,
                        [System.Text.RegularExpressions.RegexOptions]::IgnoreCase
                    )

                    if (-not $parsed.Success) {
                        $parseFailures++
                        if ($parseFailures -le 10) {
                            Write-Log "WARN" "Could not parse findstr output line: [$outLine]"
                            Write-DebugLog "Parser regex: [$patternRegex]"
                        }
                        continue
                    }

                    $filePath = $parsed.Groups[1].Value
                    $lineText = $parsed.Groups[2].Value
                    $raw = $parsed.Groups[3].Value

                    $lineNumber = 0
                    if (-not [Int32]::TryParse($lineText, [ref]$lineNumber)) {
                        $parseFailures++
                        Write-Log "WARN" "Invalid line number [$lineText] from findstr output: [$outLine]"
                        continue
                    }

                    $matches++

                    if ($debugMatchShown -lt 5) {
                        Write-DebugLog "MATCH[$matches]: file=[$filePath] line=[$lineNumber] raw=[$raw]"
                        $debugMatchShown++
                    }

                    Send-NdjsonLine $Response ([ordered]@{
                        type = "log"
                        file = $filePath
                        lineNumber = $lineNumber
                        data = (Encode-Utf8Base64 $raw)
                    })
                }

                # Read stderr after stdout has been consumed.
                $stderrText = $process.StandardError.ReadToEnd()
                $process.WaitForExit()
                $exitCode = $process.ExitCode

                Write-Log "INFO" "findstr finished. ExitCode=$exitCode OutputLines=$rawOutputLines Matches=$matches ParseFailures=$parseFailures"

                if ($stderrText) {
                    Write-Log "WARN" "findstr STDERR: [$($stderrText.Trim())]"
                }

                # findstr exit codes:
                # 0 = at least one match
                # 1 = no match
                # 2+ = error
                if ($exitCode -ge 2) {
                    $errors++
                    $message = "findstr failed for $pattern (exit code $exitCode)"
                    if ($stderrText) { $message += ": " + $stderrText.Trim() }

                    Write-Log "ERROR" $message

                    Send-NdjsonLine $Response ([ordered]@{
                        type = "search-error"
                        message = $message
                    })
                } elseif ($exitCode -eq 1) {
                    Write-DebugLog "findstr returned 1 = no matches for [$pattern]"
                } elseif ($exitCode -eq 0) {
                    Write-DebugLog "findstr returned 0 = match(es) found for [$pattern]"
                }
            } catch {
                $errors++
                Write-Log "ERROR" "Exception executing findstr for [$pattern]: $($_.Exception.ToString())"

                Send-NdjsonLine $Response ([ordered]@{
                    type = "search-error"
                    message = "Could not execute findstr for $pattern : $($_.Exception.Message)"
                })
            } finally {
                if ($process) { $process.Dispose() }
            }
        }
    }

    Write-Log "INFO" "Search complete. Query=[$Query] Processes=$processes Matches=$matches Errors=$errors"

    Send-NdjsonLine $Response ([ordered]@{
        type = "search-end"
        matches = $matches
        errors = $errors
    })
    $Response.Close()
}

# Load configuration.
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$configPath = Join-Path $scriptDir "config.json"
if (-not (Test-Path -LiteralPath $configPath -PathType Leaf)) {
    Write-Host "FATAL: config.json not found: $configPath" -ForegroundColor Red
    exit 1
}

try {
    $config = Get-Content -LiteralPath $configPath -Raw -Encoding UTF8 | ConvertFrom-Json
    if ($null -ne $config.debug) { $script:DebugEnabled = [bool]$config.debug }
    $port = [int]$config.port
    $bindAddress = if ($config.bindAddress) { [string]$config.bindAddress } else { "127.0.0.1" }
    $webRoot = Resolve-ConfiguredPath ([string]$config.webRoot) $scriptDir
    $maxSearchLength = if ($config.maxSearchLength) { [int]$config.maxSearchLength } else { 256 }
    if ($config.logPatterns) {
        $patterns = @($config.logPatterns | ForEach-Object { [string]$_ })
    } elseif ($config.logExtensions) {
        # Backward compatibility with older configs.
        $patterns = @($config.logExtensions | ForEach-Object { "*" + ([string]$_) })
    } else {
        $patterns = @("*.log", "*.txt")
    }
    if ($patterns.Count -eq 0) { $patterns = @("*.log", "*.txt") }

    $logPaths = @()
    foreach ($p in @($config.logPaths)) {
        if ([string]::IsNullOrWhiteSpace([string]$p)) { continue }
        $logPaths += (Resolve-ConfiguredPath ([string]$p) $scriptDir)
    }

    if ($port -lt 1 -or $port -gt 65535) { throw "Invalid port: $port" }
    if (-not (Test-Path -LiteralPath $webRoot -PathType Container)) { throw "Web root does not exist: $webRoot" }
    Write-DebugLog "Configuration loaded. Port=$port BindAddress=$bindAddress WebRoot=$webRoot MaxSearchLength=$maxSearchLength"
    Write-DebugLog "Log file patterns: $($patterns -join ", ")"
    Write-DebugLog "Log paths resolved: $($logPaths -join " | ")"
} catch {
    Write-Host "FATAL: Invalid configuration: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}

$listener = New-Object System.Net.HttpListener
$prefix = "http://$bindAddress`:$port/"
$listener.Prefixes.Add($prefix)

try {
    $listener.Start()
} catch {
    Write-Log "FATAL" "Could not start HTTP listener."
    Write-Log "FATAL" $_.Exception.ToString()
    if ($bindAddress -eq "127.0.0.1" -or $bindAddress -eq "localhost") {
        Write-Host "Try running PowerShell as Administrator, or use a free port." -ForegroundColor Yellow
    } else {
        Write-Host "For a non-local binding, run as Administrator and reserve the URL with netsh http add urlacl." -ForegroundColor Yellow
    }
    exit 1
}

Write-Log "INFO" "IVR Log Analyzer started"
Write-Log "INFO" "Listening on: $prefix"
Write-Log "INFO" "Log paths:"
foreach ($p in $logPaths) { Write-Log "INFO" "  $p" }
Write-Log "INFO" "Search: /api/search?q=..."

try {
    while ($listener.IsListening) {
        $context = $listener.GetContext()
        $request = $context.Request
        $response = $context.Response

        try {
            Write-DebugLog "HTTP request: $($request.HttpMethod) $($request.Url.AbsoluteUri) Remote=$($request.RemoteEndPoint)"
            $path = $request.Url.AbsolutePath

            if ($path -eq "/api/stop") {
                # Shutdown is intentionally restricted to loopback clients.
                # This prevents a remote browser from stopping the IVR analyzer
                # when bindAddress is changed to 0.0.0.0.
                $remoteAddress = $null
                try { $remoteAddress = $context.Request.RemoteEndPoint.Address } catch {}

                $isLoopback = $false
                if ($remoteAddress) {
                    $isLoopback = [System.Net.IPAddress]::IsLoopback($remoteAddress)
                }

                Write-Host ("[INFO] Stop request received from [{0}]" -f $remoteAddress)

                if (-not $isLoopback) {
                    Send-Json $response ([ordered]@{
                        type = "error"
                        message = "Server shutdown is allowed only from the local machine."
                    }) 403
                    continue
                }

                Send-Json $response ([ordered]@{
                    type = "stop"
                    message = "IVR Log Analyzer is shutting down."
                })

                Write-Host "[INFO] Shutdown requested from local machine." -ForegroundColor Yellow

                # Close the listener after the response is sent.
                $listener.Stop()
                continue
            }

            if ($path -eq "/api/search") {
                $q = $request.QueryString["q"]

                if ([string]::IsNullOrWhiteSpace($q)) {
                    Write-Host "[INFO] Dashboard request: calculating log/file/line/call/API/failure statistics..."
                    $stats = Get-Stats -Paths $logPaths -Patterns $patterns
                    Write-Host ("[INFO] Dashboard statistics: Files={0} Lines={1} Calls={2} APIs={3} Failures={4} Size={5}" -f `
                        $stats.files, $stats.totalLines, $stats.uniqueCalls, $stats.apiCalls, $stats.failures, $stats.totalSize)
                    Send-Json $response $stats
                    continue
                }

                if ($q.Length -gt $maxSearchLength) {
                    Send-Json $response ([ordered]@{
                        type = "error"
                        message = "Search value is too long. Maximum length is $maxSearchLength characters."
                    }) 400
                    continue
                }

                if ($q.IndexOf([char]0) -ge 0 -or $q -match '[\r\n]' -or $q.IndexOf('"') -ge 0) {
                    Send-Json $response ([ordered]@{
                        type = "error"
                        message = "Search value contains unsupported control characters or double quotes."
                    }) 400
                    continue
                }

                # No switches/commands are accepted from the client. The query is passed
                # only as the literal /C search string.
                $response.StatusCode = 200
                $response.ContentType = "application/x-ndjson; charset=utf-8"
                $response.SendChunked = $true
                $response.KeepAlive = $false
                Start-FindstrSearch -Response $response -Query $q -Paths $logPaths -Patterns $patterns
                continue
            }

            # Static web server.
            if ($path -eq "/") { $path = "/index.html" }

            try {
                $relative = [Uri]::UnescapeDataString($path).TrimStart("/")
            } catch {
                Send-Text $response "Bad Request" "text/plain; charset=utf-8" 400
                continue
            }

            if ($relative -match '(^|[\\/])\.\.([\\/]|$)' -or $relative -match '^[A-Za-z]:') {
                Send-Text $response "Forbidden" "text/plain; charset=utf-8" 403
                continue
            }

            $candidate = [IO.Path]::GetFullPath((Join-Path $webRoot ($relative -replace "/", "\")))
            $webRootFull = [IO.Path]::GetFullPath($webRoot)
            if (-not $webRootFull.EndsWith("\")) { $webRootFull += "\" }

            if (-not $candidate.StartsWith($webRootFull, [StringComparison]::OrdinalIgnoreCase)) {
                Send-Text $response "Forbidden" "text/plain; charset=utf-8" 403
                continue
            }

            if (-not (Test-Path -LiteralPath $candidate -PathType Leaf)) {
                Send-Text $response "Not Found" "text/plain; charset=utf-8" 404
                continue
            }

            $bytes = [IO.File]::ReadAllBytes($candidate)
            $response.ContentType = Get-ContentType $candidate
            $response.ContentLength64 = $bytes.Length
            $response.OutputStream.Write($bytes, 0, $bytes.Length)
            $response.Close()
        } catch {
            try {
                if ($response.OutputStream) {
                    Send-Text $response "Internal Server Error" "text/plain; charset=utf-8" 500
                }
            } catch {}
        }
    }
} finally {
    if ($listener) {
        $listener.Stop()
        $listener.Close()
    }
}
