IVR Log Analyzer v8

Run:
    .\server.ps1

Default:
    http://127.0.0.1:7070/

The server uses Windows findstr.exe for server-side searching.

Log file patterns:
The configuration now uses "logPatterns" instead of relying only on file
extensions. The default patterns include:
    *.log
    *.log.*
    *.txt
    *.out
    *.trace

This means rotated logs such as:
    test.log
    test.log.1
    test.log.20260921
are included in both dashboard statistics and searches.

The server also keeps backward compatibility with older config files that
use "logExtensions". In that case each extension is converted to a pattern
such as "*.log".

Dashboard statistics:
The initial GET /api/search (without q) calculates statistics by streaming
configured log files line-by-line. It reports files, total log lines, unique
calls, API calls, failures, total size, locations, and latest file without
loading complete log files into memory. Rotated files matching logPatterns
are included in all these statistics.

Search:
GET /api/search?q=010

Search results are streamed as NDJSON and use findstr.exe. File/line parsing
handles Windows drive-letter colons and rotated filenames correctly.

Shutdown API:
GET /api/stop stops the server. For safety it accepts shutdown requests only
from the local machine (loopback). The Turn Off Server button calls this API
after confirmation. Run server.ps1 again to restart.
