var allRecords = [];
var filteredRecords = [];
var anomalyGapThresholdMs = 5000;
var MAX_RENDER_ROWS = 500;
var xhrSearch = null;

window.onload = function () {
    loadStats();
    var input = document.getElementById("searchInput");
    input.onkeypress = function (e) {
        e = e || window.event;
        if ((e.keyCode || e.which) === 13) {
            performSearch();
            return false;
        }
    };
    document.getElementById("filterFlow").onchange = applyClientFilters;
    document.getElementById("filterStep").onchange = applyClientFilters;
    document.getElementById("filterLevel").onchange = applyClientFilters;
    document.getElementById("filterDate").onchange = applyClientFilters;
    document.getElementById("filterText").onkeyup = applyClientFilters;
};

function formatBytes(bytes) {
    if (!bytes) return "0 Bytes";
    var sizes = ["Bytes", "KB", "MB", "GB", "TB"];
    var i = Math.floor(Math.log(bytes) / Math.log(1024));
    return parseFloat((bytes / Math.pow(1024, i)).toFixed(1)) + " " + sizes[i];
}

function formatNumber(value) {
    if (value === null || value === undefined) return "0";
    var s = String(value);
    var out = "";
    var count = 0;
    for (var i = s.length - 1; i >= 0; i--) {
        out = s.charAt(i) + out;
        count++;
        if (count === 3 && i > 0) {
            out = "," + out;
            count = 0;
        }
    }
    return out;
}

/* IE11-safe UTF-8 Base64 decoder. Handles surrogate pairs as well. */
function base64ToUtf8(base64) {
    var bin, bytes, i, out = "", b1, b2, b3, b4, cp;
    try {
        bin = window.atob(base64);
        bytes = new Uint8Array(bin.length);
        for (i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);

        for (i = 0; i < bytes.length;) {
            b1 = bytes[i++];
            if (b1 < 0x80) {
                out += String.fromCharCode(b1);
            } else if (b1 < 0xE0 && i < bytes.length) {
                b2 = bytes[i++];
                out += String.fromCharCode(((b1 & 0x1F) << 6) | (b2 & 0x3F));
            } else if (b1 < 0xF0 && i + 1 < bytes.length) {
                b2 = bytes[i++]; b3 = bytes[i++];
                out += String.fromCharCode(((b1 & 0x0F) << 12) | ((b2 & 0x3F) << 6) | (b3 & 0x3F));
            } else if (i + 2 < bytes.length) {
                b2 = bytes[i++]; b3 = bytes[i++]; b4 = bytes[i++];
                cp = ((b1 & 0x07) << 18) | ((b2 & 0x3F) << 12) | ((b3 & 0x3F) << 6) | (b4 & 0x3F);
                cp -= 0x10000;
                out += String.fromCharCode(0xD800 + (cp >> 10), 0xDC00 + (cp & 0x3FF));
            } else {
                break;
            }
        }
        return out;
    } catch (e) {
        return "";
    }
}

function loadStats() {
    var xhr = new XMLHttpRequest();
    xhr.open("GET", "/api/search", true);
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
            try {
                var d = JSON.parse(xhr.responseText);
                if (d.type === "stats") {
                    document.getElementById("statFiles").innerText = d.files;
                    document.getElementById("statLines").innerText = formatNumber(d.totalLines);
                    document.getElementById("statCalls").innerText = formatNumber(d.uniqueCalls);
                    document.getElementById("statApiCalls").innerText = formatNumber(d.apiCalls);
                    document.getElementById("statFailures").innerText = formatNumber(d.failures);
                    document.getElementById("statSize").innerText = formatBytes(d.totalSize);
                    document.getElementById("statLocations").innerText = d.logPaths;
                    document.getElementById("statLatest").innerText = d.latestFile || "-";
                    if (d.missingPaths && d.missingPaths.length) {
                        document.getElementById("searchStatus").innerText =
                            "Dashboard loaded. " + d.missingPaths.length + " configured log location(s) are missing.";
                    }
                }
            } catch (e) {}
        }
    };
    xhr.send(null);
}

function quickSearch(term) {
    document.getElementById("searchInput").value = term;
    performSearch();
}

function normalizeForParsing(s) {
    return (s || "").replace(/\u00A0/g, " ").replace(/[\t ]+/g, " ");
}

function parseLogLine(raw) {
    var r = {
        raw: raw, timestamp: "", level: "", server: "", callId: "",
        flow: "", step: "", action: "", message: "", parsed: false
    };
    var dash = raw.indexOf(" - ");
    if (dash < 0) {
        r.message = raw;
        return r;
    }

    var prefix = normalizeForParsing(raw.substring(0, dash));
    var rest = raw.substring(dash + 3);
    var prefixParts = prefix.split(" ");
    if (prefixParts.length >= 3) {
        r.timestamp = prefixParts[0] + " " + prefixParts[1];
        r.level = prefixParts.slice(2).join(" ").trim();
    } else {
        r.timestamp = prefix;
    }

    var p1 = rest.indexOf("|");
    if (p1 < 0) {
        r.message = rest;
        return r;
    }

    var serverCall = rest.substring(0, p1);
    var sep = serverCall.indexOf("-");
    /* The actual format is SERVER-CALLID. Server names may contain hyphens,
       so use the first hyphen; the call ID is everything after it. */
    if (sep > 0) {
        r.server = serverCall.substring(0, sep);
        r.callId = serverCall.substring(sep + 1);
    } else {
        r.callId = serverCall;
    }

    var remain = rest.substring(p1 + 1);
    var a = remain.indexOf("|");
    if (a < 0) { r.flow = remain; return r; }
    r.flow = remain.substring(0, a);
    remain = remain.substring(a + 1);

    var b = remain.indexOf("|");
    if (b < 0) { r.step = remain; return r; }
    r.step = remain.substring(0, b);
    remain = remain.substring(b + 1);

    var c = remain.indexOf("|");
    if (c < 0) { r.action = remain; r.parsed = true; return r; }
    r.action = remain.substring(0, c);
    r.message = remain.substring(c + 1);
    r.parsed = true;
    return r;
}

function analyzeRecord(r) {
    var text = (r.raw || "").toLowerCase();
    r.api = "";
    r.statusCode = "";
    r.responseStatus = "";
    r.severity = "info";

    var apiMatch = (r.raw || "").match(/APIClient\.([A-Za-z0-9_]+)/);
    if (apiMatch) r.api = apiMatch[1];

    var statusMatch = (r.raw || "").match(/statusCode\s+([1-5][0-9][0-9])/i);
    if (statusMatch) r.statusCode = statusMatch[1];

    var rs = (r.raw || "").match(/RESPONSE_STATUS\s+([A-Za-z0-9_\\-]+)/i);
    if (rs) r.responseStatus = rs[1];

    if (text.indexOf("failure") >= 0 || text.indexOf("error") >= 0 ||
        text.indexOf("exception") >= 0 || text.indexOf(" false") >= 0 ||
        /statuscode\s+5\d\d/.test(text) || /statuscode\s+4\d\d/.test(text)) {
        r.severity = "error";
    } else if (text.indexOf("warning") >= 0 || text.indexOf(" warn") >= 0) {
        r.severity = "warning";
    } else if (text.indexOf("success") >= 0 || text.indexOf(" true") >= 0 ||
               /statuscode\s+2\d\d/.test(text)) {
        r.severity = "success";
    }
}

function performSearch() {
    var q = document.getElementById("searchInput").value.trim();
    var status = document.getElementById("searchStatus");

    if (xhrSearch) {
        try { xhrSearch.abort(); } catch (e) {}
        xhrSearch = null;
    }

    allRecords = [];
    filteredRecords = [];
    document.getElementById("logTableBody").innerHTML = "";
    document.getElementById("filtersBar").style.display = "none";
    document.getElementById("tabJourney").disabled = true;

    if (!q) {
        status.innerText = "No search performed. Enter a search value to view logs.";
        loadStats();
        return;
    }

    document.getElementById("filtersBar").style.display = "flex";
    status.innerText = "Searching for: " + q + "...";

    var xhr = new XMLHttpRequest();
    xhrSearch = xhr;
    xhr.open("GET", "/api/search?q=" + encodeURIComponent(q), true);

    var processed = 0;
    var pending = "";

    xhr.onreadystatechange = function () {
        if (xhr.readyState === 3 || xhr.readyState === 4) {
            var chunk = xhr.responseText.substring(processed);
            processed = xhr.responseText.length;
            pending += chunk;

            var lines = pending.split(/\r?\n/);
            pending = lines.pop();

            for (var i = 0; i < lines.length; i++) processNdjson(lines[i]);

            if (xhr.readyState === 4) {
                if (pending) processNdjson(pending);
                if (xhr.status !== 200 && xhr.status !== 0) {
                    status.innerText = "Search failed. HTTP " + xhr.status;
                }
                xhrSearch = null;
            }
        }
    };
    xhr.onerror = function () {
        status.innerText = "Search failed: connection error.";
        xhrSearch = null;
    };
    xhr.send(null);
}

function processNdjson(line) {
    if (!line || !line.trim()) return;
    try {
        var o = JSON.parse(line);
        var status = document.getElementById("searchStatus");

        if (o.type === "search-start") {
            status.innerText = "Searching for: " + o.query + "...";
        } else if (o.type === "log") {
            var r = parseLogLine(base64ToUtf8(o.data));
            r.file = o.file || "";
            r.lineNumber = o.lineNumber || 0;
            analyzeRecord(r);
            allRecords.push(r);

            if (allRecords.length === 1 || allRecords.length % 25 === 0) {
                updateFiltersDropdowns();
                applyClientFilters();
            }
            document.getElementById("tabJourney").disabled = false;
            status.innerText = "Searching for: " + document.getElementById("searchInput").value.trim() +
                " — " + allRecords.length + " matches received...";
        } else if (o.type === "search-error") {
            status.innerText = "Search warning: " + o.message;
        } else if (o.type === "search-end") {
            updateFiltersDropdowns();
            applyClientFilters();
            status.innerText = o.matches === 0 ?
                "No matching logs found." :
                "Search complete. " + o.matches + " matches.";
            if (o.errors) status.innerText += " " + o.errors + " search warning(s).";
        }
    } catch (e) {}
}

function populateSelect(id, values) {
    var el = document.getElementById(id);
    var current = el.value;
    while (el.options.length > 1) el.remove(1);

    var keys = [];
    for (var k in values) if (values.hasOwnProperty(k)) keys.push(k);
    keys.sort();

    for (var i = 0; i < keys.length; i++) {
        var opt = document.createElement("option");
        opt.value = keys[i];
        opt.text = keys[i];
        if (keys[i] === current) opt.selected = true;
        el.appendChild(opt);
    }
}

function updateFiltersDropdowns() {
    var flows = {}, steps = {}, levels = {}, dates = {};
    for (var i = 0; i < allRecords.length; i++) {
        var r = allRecords[i];
        if (r.flow) flows[r.flow] = true;
        if (r.step) steps[r.step] = true;
        if (r.level) levels[r.level] = true;
        if (r.timestamp) dates[r.timestamp.substring(0, 10)] = true;
    }
    populateSelect("filterFlow", flows);
    populateSelect("filterStep", steps);
    populateSelect("filterLevel", levels);
    populateSelect("filterDate", dates);
}

function applyClientFilters() {
    var flow = document.getElementById("filterFlow").value;
    var step = document.getElementById("filterStep").value;
    var level = document.getElementById("filterLevel").value;
    var date = document.getElementById("filterDate").value;
    var text = document.getElementById("filterText").value.toLowerCase();

    filteredRecords = [];
    for (var i = 0; i < allRecords.length; i++) {
        var r = allRecords[i];
        if (flow && r.flow !== flow) continue;
        if (step && r.step !== step) continue;
        if (level && r.level !== level) continue;
        if (date && r.timestamp.substring(0, 10) !== date) continue;

        var searchable = [r.timestamp, r.level, r.server, r.callId, r.flow, r.step,
            r.action, r.message, r.file, r.api, r.statusCode, r.responseStatus].join(" ").toLowerCase();
        if (text && searchable.indexOf(text) < 0) continue;
        filteredRecords.push(r);
    }
    renderTable();
}

function levelClass(r) {
    if (r.severity === "error") return "badge-error";
    if (r.severity === "warning") return "badge-warning";
    if (r.severity === "success") return "badge-success";
    return "badge-info";
}

function appendCell(tr, value) {
    var td = document.createElement("td");
    td.appendChild(document.createTextNode(value == null ? "" : String(value)));
    tr.appendChild(td);
}

function renderTable() {
    var tbody = document.getElementById("logTableBody");
    tbody.innerHTML = "";

    var count = Math.min(MAX_RENDER_ROWS, filteredRecords.length);
    for (var i = 0; i < count; i++) {
        var r = filteredRecords[i];
        var tr = document.createElement("tr");
        tr.className = r.severity;
        tr.onclick = (function (record) {
            return function () { showDetails(record); };
        })(r);

        appendCell(tr, r.timestamp);

        var levelTd = document.createElement("td");
        var badge = document.createElement("span");
        badge.className = levelClass(r);
        badge.appendChild(document.createTextNode(r.level || "INFO"));
        levelTd.appendChild(badge);
        tr.appendChild(levelTd);

        appendCell(tr, r.server);
        appendCell(tr, r.callId);
        appendCell(tr, r.flow);
        appendCell(tr, r.step);
        appendCell(tr, r.action);
        appendCell(tr, r.message);
        appendCell(tr, r.file);
        tbody.appendChild(tr);
    }

    if (filteredRecords.length > MAX_RENDER_ROWS) {
        var info = document.createElement("tr");
        var td = document.createElement("td");
        td.colSpan = 9;
        td.className = "limit-note";
        td.appendChild(document.createTextNode("Showing first " + MAX_RENDER_ROWS +
            " of " + filteredRecords.length + " filtered records."));
        info.appendChild(td);
        tbody.appendChild(info);
    }
}

function showDetails(r) {
    var grid = document.getElementById("modalGrid");
    grid.innerHTML = "";

    var fields = [
        ["Timestamp", r.timestamp], ["Level", r.level], ["Server", r.server],
        ["Call ID", r.callId], ["Flow", r.flow], ["Step", r.step],
        ["Action", r.action], ["Source File", r.file], ["Line Number", r.lineNumber],
        ["API", r.api], ["Status Code", r.statusCode], ["Response Status", r.responseStatus]
    ];

    for (var i = 0; i < fields.length; i++) {
        var d = document.createElement("div");
        var label = document.createElement("span");
        label.appendChild(document.createTextNode(fields[i][0] + ": "));
        d.appendChild(label);
        d.appendChild(document.createTextNode(fields[i][1] == null ? "" : String(fields[i][1])));
        grid.appendChild(d);
    }

    document.getElementById("modalMessage").innerText = r.message || "";
    document.getElementById("modalRawLog").innerText = r.raw || "";
    document.getElementById("detailsModal").style.display = "flex";
}

function closeModal() {
    document.getElementById("detailsModal").style.display = "none";
}

function switchTab(name) {
    var logs = document.getElementById("logsView");
    var journey = document.getElementById("journeyView");
    document.getElementById("tabLogs").className = name === "logs" ? "tab-btn active" : "tab-btn";
    document.getElementById("tabJourney").className = name === "journey" ? "tab-btn active" : "tab-btn";
    logs.className = name === "logs" ? "view-content active" : "view-content";
    journey.className = name === "journey" ? "view-content active" : "view-content";
    if (name === "journey") renderJourney();
}

function parseTimeMs(s) {
    var p = (s || "").split(" ");
    if (p.length < 2) return 0;
    var d = p[0].split("/"), t = p[1].split(":");
    if (d.length !== 3 || t.length !== 4) return 0;
    var dt = new Date(parseInt(d[2], 10), parseInt(d[1], 10) - 1, parseInt(d[0], 10),
        parseInt(t[0], 10), parseInt(t[1], 10), parseInt(t[2], 10), parseInt(t[3], 10));
    return dt.getTime();
}

function renderJourney() {
    var container = document.getElementById("timelineContainer");
    var header = document.getElementById("journeyHeader");
    container.innerHTML = "";

    if (!allRecords.length) {
        header.innerText = "No call records available.";
        return;
    }

    var records = allRecords.slice(0);
    records.sort(function (a, b) { return parseTimeMs(a.timestamp) - parseTimeMs(b.timestamp); });

    var callId = records[0].callId || "Unknown Call";
    header.innerText = "CALL JOURNEY: " + callId + " (" + records.length + " events)";

    var previous = 0;
    for (var i = 0; i < records.length; i++) {
        var r = records[i], current = parseTimeMs(r.timestamp);

        if (i > 0 && previous && current) {
            var gap = current - previous;
            if (gap > 0) {
                var gapEl = document.createElement("div");
                gapEl.className = gap > anomalyGapThresholdMs ? "timeline-gap long" : "timeline-gap";
                gapEl.appendChild(document.createTextNode("↓ +" + gap + " ms" +
                    (gap > anomalyGapThresholdMs ? "  LONG GAP" : "")));
                container.appendChild(gapEl);
            }
        }
        previous = current;

        var item = document.createElement("div");
        item.className = "timeline-item";

        var time = document.createElement("div");
        time.className = "timeline-time";
        time.appendChild(document.createTextNode(r.timestamp));
        item.appendChild(time);

        var step = document.createElement("div");
        step.className = "timeline-step";
        step.appendChild(document.createTextNode(r.step || r.action || "Event"));
        item.appendChild(step);

        if (r.message) {
            var msg = document.createElement("div");
            msg.className = "timeline-msg";
            msg.appendChild(document.createTextNode(r.message));
            item.appendChild(msg);
        }
        container.appendChild(item);
    }
}

function stopServer() {
    document.getElementById("stopConfirm").style.display = "block";
}

function closeStopConfirm() {
    document.getElementById("stopConfirm").style.display = "none";
}

function confirmStopServer() {
    var button = document.getElementById("stopServerButton");
    var status = document.getElementById("searchStatus");

    closeStopConfirm();
    button.disabled = true;
    button.innerText = "Turning Off...";

    var xhr = new XMLHttpRequest();
    xhr.open("GET", "/api/stop", true);

    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4) {
            if (xhr.status === 200) {
                status.innerText = "Server stopped. Run server.ps1 again to start it.";
                button.innerText = "Server Stopped";
            } else if (xhr.status === 403) {
                status.innerText = "Server refused shutdown: only the local machine can turn it off.";
                button.disabled = false;
                button.innerText = "Turn Off Server";
            } else {
                status.innerText = "Could not stop the server. HTTP " + xhr.status;
                button.disabled = false;
                button.innerText = "Turn Off Server";
            }
        }
    };

    xhr.onerror = function () {
        // The server may close the listener immediately after sending the response.
        // Give the user a useful local-server state rather than treating it as a
        // normal search failure.
        status.innerText = "Server shutdown requested. The server should now be stopped.";
        button.innerText = "Server Stopped";
        button.disabled = true;
    };

    xhr.send(null);
}
